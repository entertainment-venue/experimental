// +build tools

package tools

import (
	_ "knative.dev/pkg/hack"
)
